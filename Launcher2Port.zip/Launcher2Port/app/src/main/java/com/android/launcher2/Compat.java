package com.android.launcher2;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;

/** Replacements for hidden/removed APIs that Launcher2 used on API 16. */
final class Compat {
    private Compat() {}

    static final String ACTION_GLOBAL_SEARCH = "android.search.action.GLOBAL_SEARCH";
    static final String ACTION_GLOBAL_SEARCH_ACTIVITY_CHANGED =
            "android.search.action.GLOBAL_SEARCH_ACTIVITY_CHANGED";
    static final String ACTION_SEARCHABLES_CHANGED =
            "android.search.action.SEARCHABLES_CHANGED";
    static final String SEARCH_SOURCE_KEY = "source";

    /** Replaces the hidden SearchManager.getGlobalSearchActivity(). */
    static ComponentName getGlobalSearchActivity(Context context) {
        Intent intent = new Intent(ACTION_GLOBAL_SEARCH);
        ResolveInfo ri = context.getPackageManager()
                .resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
        if (ri == null || ri.activityInfo == null) return null;
        return new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name);
    }

    /** Android 14+ requires an export flag on context-registered receivers. */
    static void registerReceiver(Context context, BroadcastReceiver r, IntentFilter f) {
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            context.registerReceiver(r, f);
        }
    }
}
