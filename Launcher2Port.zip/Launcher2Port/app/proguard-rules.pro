-keep class com.android.launcher2.Launcher {
  public void previousScreen(android.view.View);
  public void nextScreen(android.view.View);
  public void launchHotSeat(android.view.View);
  public void onClickSearchButton(android.view.View);
  public void onClickVoiceButton(android.view.View);
  public void onClickConfigureButton(android.view.View);
  public void onClickAllAppsButton(android.view.View);
  public void onClickAppMarketButton(android.view.View);
  public void dismissWorkspaceCling(android.view.View);
  public void dismissAllAppsCling(android.view.View);
}

-keep class com.android.launcher2.CellLayout {
  public float getBackgroundAlpha();
  public void setBackgroundAlpha(float);
  public float getDimmableProgress();
  public void setDimmableProgress(float);
  public float getHoverScale();
  public void setHoverScale(float);
  public float getHoverAlpha();
  public void setHoverAlpha(float);
}

-keep class com.android.launcher2.DragLayer$LayoutParams {
  public void setWidth(int);
  public int getWidth();
  public void setHeight(int);
  public int getHeight();
  public void setX(int);
  public int getX();
  public void setY(int);
  public int getY();
}

-keep class com.android.launcher2.CellLayout$LayoutParams {
  public void setWidth(int);
  public int getWidth();
  public void setHeight(int);
  public int getHeight();
  public void setX(int);
  public int getX();
  public void setY(int);
  public int getY();
}

-keep class com.android.launcher2.Workspace {
  public float getBackgroundAlpha();
  public void setBackgroundAlpha(float);
  public float getChildrenOutlineAlpha();
  public void setChildrenOutlineAlpha(float);
  public void setVerticalWallpaperOffset(float);
  public float getVerticalWallpaperOffset();
  public void setHorizontalWallpaperOffset(float);
  public float getHorizontalWallpaperOffset();
}

-keep class com.android.launcher2.AllApps3D$Defines {
  *;
}

-keep class com.android.launcher2.ClippedImageView {
  *;
}
