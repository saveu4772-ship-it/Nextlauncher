# Launcher2Port (AOSP Launcher2 4.1.2_r1 -> Android 15 / API 35)

Open this folder in Android Studio (Ladybug or newer, JDK 17) and let Gradle sync.
Gradle wrapper jar is not included; Android Studio will use/download Gradle 8.9.

## What changed vs. AOSP
- Android.mk -> Gradle (compileSdk/targetSdk 35, minSdk 26, no external deps).
  applicationId `com.launcher2.port`; R namespace stays `com.android.launcher`.
- Manifest: android:exported everywhere, `<queries>` + QUERY_ALL_PACKAGES for package
  visibility, removed system-only permissions (BIND_APPWIDGET, CALL_PHONE, GET_ACCOUNTS,
  PRELOAD_WORKSPACE), provider authority -> `com.launcher2.port.settings`.
- New `Compat.java`: replaces hidden SearchManager.getGlobalSearchActivity() and
  hidden search broadcast constants; export-flag-aware registerReceiver().
- Search/voice buttons launch the global search activity by intent (SearchManager.startSearch
  with a Rect is hidden and the legacy search dialog is gone).
- Removed: RocketLauncher (Daydream easter egg; needed removed support-v13 BasicDream),
  com.android.common.Search, SystemProperties debug hooks.
- Canvas: Region.Op.REPLACE -> INTERSECT, save(CLIP_SAVE_FLAG) -> save() (unsupported on API 28+).
- Theme opts out of Android 15 edge-to-edge enforcement (windowOptOutEdgeToEdgeEnforcement).

## Known limitations / not done yet
- NOT COMPILED OR TESTED (no Android SDK was available while porting). Expect a few compile
  errors on first sync; they should be small.
- Default workspace references 2012 apps (browser, gallery...); most won't resolve, so the
  home screen starts mostly empty. Edit res/xml/default_workspace.xml.
- INSTALL_SHORTCUT broadcasts are ignored by Android 8+; pinned-shortcut API not implemented.
- Widgets: binding needs the user to approve via the system bind dialog (already handled by
  Launcher's ACTION_APPWIDGET_BIND path); default-workspace widgets won't auto-bind.
- Rotation stays locked on phones (original allow_rotation=false). Set it in res/values/config.xml.
- Set as default: Settings > Apps > Default apps > Home app.

## Building without a PC
Push this folder to a GitHub repo; .github/workflows/build.yml builds a debug APK in the cloud.
Actions tab -> latest run -> Artifacts -> Launcher2Port-debug. Build errors show in the run log.
